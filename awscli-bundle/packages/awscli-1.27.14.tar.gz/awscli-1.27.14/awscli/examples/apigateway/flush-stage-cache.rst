**To flush the cache for an API's stage**

Command::

  aws apigateway flush-stage-cache --rest-api-id 1234123412 --stage-name dev
